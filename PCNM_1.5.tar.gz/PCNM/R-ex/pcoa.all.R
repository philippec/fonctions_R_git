### Name: pcoa.all
### Title: Principal Coordinate Analysis
### Aliases: pcoa.all
### Keywords: multivariate

### ** Examples

# Oribatid mite data from Borcard and Legendre (1994)
library(vegan)
data(mite)      # 70 peat cores, 35 species

mite.D <- vegdist(mite, "bray")
res <- pcoa.all(mite.D)
res <- pcoa.all(mite.D, all=TRUE)



