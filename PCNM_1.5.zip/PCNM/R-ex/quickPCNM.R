### Name: quickPCNM
### Title: Quick PCNM spatial eigenfunction analysis
### Aliases: quickPCNM
### Keywords: multivariate spatial

### ** Examples

# Oribatid mite data from Borcard and Legendre (1994)
library(vegan)
data(mite)      # 70 peat cores, 35 species
data(mite.xy)   # Core geographic coordinates

mite.hel <- decostand(mite, "hellinger")

# A. Usual case with defaut settings; works well in most situations
quick.1 <- quickPCNM(mite.hel, mite.xy)
summary(quick.1)

# B. Same with user-provided truncation level
quick.2 <- quickPCNM(mite.hel, mite.xy, thresh=1.500)

# C. Same as A but with precomputed PCNM variables, a modified  
# alpha level and rescaling of x-y coordinates
quick.3 <- quickPCNM(mite.hel, mite.xy, myPCNM=quick.1$PCNM, alpha=0.01, range=TRUE)



