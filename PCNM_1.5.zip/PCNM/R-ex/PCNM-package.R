### Name: PCNM-package
### Title: PCNM spatial eigenfunctions
### Aliases: PCNM-package
### Keywords: package

### ** Examples


# Oribatid mite data from Borcard and Legendre (1994)
library(vegan)
data(mite)      # 70 peat cores, 35 species
data(mite.xy)   # Core geographic coordinates

# Compute PCNM eigenfunctions
res.pcnm <- PCNM(dist(mite.xy), thresh=1.012)

# PCNM eigenfunction analysis: quickPCNM
mite.hel <- decostand(mite, "hellinger")
res.quick <- quickPCNM(mite.hel, mite.xy, thresh=1.012)

# Principal coordinate ordination
mite.log <- log1p(mite[1:30,-35])
mite.D <- vegdist(mite.log, "bray")
res <- pcoa(mite.D)
mite.log.st = apply(mite.log, 2, scale, center=TRUE, scale=TRUE)
biplot(res, mite.log.st)



