### Name: PCNM
### Title: PCNM spatial eigenfunctions
### Aliases: PCNM
### Keywords: multivariate spatial

### ** Examples

# Oribatid mite data from Borcard and Legendre (1994)
library(vegan)
data(mite)      # 70 peat cores, 35 species
data(mite.xy)   # Core geographic coordinates

mite.D <- dist(mite.xy)   # Geographic distance matrix
pcnm1 <- PCNM(mite.D, thresh=1.012)
pcnm2 <- PCNM(mite.D, thresh=1.012, all=TRUE)
pcnm3 <- PCNM(mite.D, thresh=1.012, all=TRUE, include.zero=TRUE)

# Plot maps of the first 3 PCNM eigenfunctions of file pcnm1
par(mfrow=c(1,3))
s.value(mite.xy, pcnm1$vectors[,1], clegend=0, sub="PCNM 1", csub=2.5)
s.value(mite.xy, pcnm1$vectors[,2], clegend=0, sub="PCNM 2", csub=2.5)
s.value(mite.xy, pcnm1$vectors[,3], clegend=0, sub="PCNM 3", csub=2.5)

# Plot maps of PCNM eigenfunctions no. 1 (eigenvalue = 77.12495), 
# no. 44 (eigenvalue = 0), and no. 70 (eigenvalue = -18.92951) of file pcnm3
par(mfrow=c(1,3))
s.value(mite.xy, pcnm3$vectors[,1] , clegend=0, sub="PCNM 1" , csub=2.5)
s.value(mite.xy, pcnm3$vectors[,44], clegend=0, sub="PCNM 44", csub=2.5)
s.value(mite.xy, pcnm3$vectors[,70], clegend=0, sub="PCNM 70", csub=2.5)



