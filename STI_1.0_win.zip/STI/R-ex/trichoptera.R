### Name: trichoptera
### Title: Trichoptera data set
### Aliases: trichoptera
### Keywords: datasets

### ** Examples

data(trichoptera)



