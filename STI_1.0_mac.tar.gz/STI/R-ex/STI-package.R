### Name: STI-package
### Title: Space-time ANOVA models without replications.
### Aliases: STI-package
### Keywords: package

### ** Examples


data(trichoptera)

#log-transform species data (excluding site and time colums)
trich.log = log(trichoptera[,-c(1,2)]+1) 

#Run space-time interaction test using model "5"
STImodels(trich.log, S=22, T=10, nperm=999, model="5")

#Run space-time analysis with tests for main effects after testing interaction (which is significant)
quickSTI(trich.log, S=22, T=10, nperm=999)

#Run space-time analysis for time blocks 6 and 7. 
#Interaction is then not significant and tests of main effects are done using model 2
quickSTI(trich.log[111:154,], S=22, T=2, nperm=999)




